import type { ImagePlaceholder, ImagePlaceholderData, ImagePlaceholderPageConfig } from './types'
import { IComponentPropsExtender } from 'feature-components'
import { IMAGE_PLACEHOLDER_COMPONENTS_TYPES } from './imagePlaceholderComponentTypes'

export default function createFactory(imageClientApi: any) {
	return (
		pageConfig: ImagePlaceholderPageConfig
	): IComponentPropsExtender<
		{ getPlaceholder: (imagePlaceholderData: ImagePlaceholderData) => ImagePlaceholder },
		unknown
	> => {
		const { isSEOBot, staticMediaUrl } = pageConfig

		const getPlaceholder = ({ fittingType, src, target, options }: ImagePlaceholderData): ImagePlaceholder => {
			const placeholder = imageClientApi.getPlaceholder(fittingType, src, target, {
				...(options || {}),
				isSEOBot,
				autoEncode: true,
			})

			if (placeholder && placeholder.uri && !placeholder.uri.startsWith('http')) {
				placeholder.uri = `${staticMediaUrl}/${placeholder.uri}`
			}

			if (placeholder?.srcset?.dpr) {
				placeholder.srcset.dpr = placeholder.srcset.dpr.map((s: string) =>
					s.startsWith('http') ? s : `${staticMediaUrl}/${s}`
				)
			}

			return placeholder
		}

		return {
			componentTypes: IMAGE_PLACEHOLDER_COMPONENTS_TYPES,
			getExtendedProps: () => ({ getPlaceholder }),
		}
	}
}
