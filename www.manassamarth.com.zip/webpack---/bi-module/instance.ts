import { BiModule } from '@wix/thunderbolt-environment'

export const instance = BiModule()
window.bi = instance
