export const name = 'contentReflow' as const
export const REFLOW_BANNER_COMP_ID = 'CONTENT_REFLOW_BANNER'
export const ContentReflowVisibilitySymbol = Symbol('ContentReflowVisibility')
export const ContentReflowZoomDetectionSymbol = Symbol('ContentReflowZoomDetection')
