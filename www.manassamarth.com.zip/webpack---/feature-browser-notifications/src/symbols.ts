export const name = 'browserNotifications' as const
export const BrowserNotificationRegistrationSymbol = Symbol('BrowserNotificationRegistration')
