import fastdom from 'fastdom'
import { BIReporter, ViewerModel } from '@wix/thunderbolt-symbols'
import { applyPolyfillsIfNeeded } from './polyfills'
import { prefersReducedMotion } from '@wix/thunderbolt-environment'
// eslint-disable-next-line no-restricted-syntax
import mediaResizeMap from '@wix/santa-animations/src/mediaResizeMap'
import wixCustomElementsRegistry from '@wix/wix-custom-elements'

type CustomElementsMediaData = Pick<ViewerModel, 'experiments' | 'media' | 'requestUrl'>

const initWixCustomElementsRegistry = () => {
	const resizeService = {
		init: (callback: any) => new ResizeObserver(callback),
	}

	const windowResizeService = {
		init: (callback: any) => window.addEventListener('resize', callback),
	}

	return wixCustomElementsRegistry.init({ resizeService, windowResizeService })
}

const buildCustomElementsMediaParams = (
	partialViewerModel: CustomElementsMediaData,
	biService: BIReporter,
	wixCustomElements?: any
) => {
	const getDevicePixelRatio = () => {
		const isMSMobileDevice = /iemobile/i.test(navigator.userAgent)
		if (isMSMobileDevice) {
			return Math.round(
				window.screen.availWidth / (window.screen.width || window.document.documentElement.clientWidth)
			)
		}
		return window.devicePixelRatio
	}

	const isExperimentOpen = (experiment: string) => Boolean(partialViewerModel.experiments[experiment])

	const getMediaDimensionsByEffect = (bgEffectName: string, width: number, height: number, screenHeight: number) => {
		const { getMediaDimensions, ...rest } = mediaResizeMap[bgEffectName] || {}
		return getMediaDimensions
			? { ...getMediaDimensions(width, height, screenHeight), ...rest }
			: { width, height, ...rest }
	}

	const environmentConsts = {
		staticMediaUrl: partialViewerModel.media.staticMediaUrl,
		mediaRootUrl: partialViewerModel.media.mediaRootUrl,
		experiments: {},
		isViewerMode: true,
		devicePixelRatio: getDevicePixelRatio(),
	}

	const services = {
		mutationService: fastdom,
		// @ts-ignore window.bi is initialized by bi.inline script
		biService,
		isExperimentOpen,
	}
	const mediaServices = { getMediaDimensionsByEffect, ...services }

	return {
		...partialViewerModel,
		wixCustomElements: wixCustomElements || initWixCustomElementsRegistry(),
		services,
		environmentConsts,
		mediaServices,
	}
}

export const initCustomElements = (
	partialViewerModelParam: CustomElementsMediaData,
	biService: BIReporter,
	wixCustomElementsParam?: any
) => {
	const customElementsParamsPromise = applyPolyfillsIfNeeded().then(() =>
		buildCustomElementsMediaParams(partialViewerModelParam, biService, wixCustomElementsParam)
	)
	const domInteractive = new Promise<void>((resolve) => {
		if (document.readyState === 'complete' || document.readyState === 'interactive') {
			resolve()
		} else {
			document.addEventListener('readystatechange', () => resolve(), { once: true })
		}
	})

	Promise.all([customElementsParamsPromise, domInteractive]).then(
		([{ services, environmentConsts, wixCustomElements, media, requestUrl, mediaServices }]) => {
			wixCustomElements.defineWixVideo(mediaServices, {
				...environmentConsts,
				staticVideoUrl: media.staticVideoUrl,
				prefersReducedMotion: prefersReducedMotion(window, requestUrl),
			})
			wixCustomElements.defineWixDropdownMenu(services, environmentConsts)
			wixCustomElements.defineWixIframe(services, environmentConsts)

			wixCustomElements.defineWixImage(mediaServices, environmentConsts)
			wixCustomElements.defineWixBgImage(mediaServices, environmentConsts)
			wixCustomElements.defineWixBgMedia(mediaServices, environmentConsts)
		}
	)
	window.__imageClientApi__ = wixCustomElementsRegistry.imageClientApi
}
