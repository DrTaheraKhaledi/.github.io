export const name = 'sessionManager' as const

export const SessionManagerSymbol = Symbol('SessionManager')
