export const name = 'navigationManager' as const
export const NavigationManagerSymbol = Symbol('NavigationManager')
