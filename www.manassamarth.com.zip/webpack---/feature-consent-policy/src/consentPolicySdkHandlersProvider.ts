import { withDependencies } from '@wix/thunderbolt-ioc'
import type { ConsentPolicy } from '@wix/cookie-consent-policy-client'
import type { IPageDidMountHandler, SdkHandlersProvider } from '@wix/thunderbolt-symbols'
import { ConsentPolicySymbol } from './symbols'
import type { ConsentPolicySdkHandlers, ConsentPolicyUpdatesListener, IConsentPolicy } from './types'

export const ConsentPolicySdkHandlersProvider = withDependencies(
	[ConsentPolicySymbol],
	(consentPolicyApi: IConsentPolicy): SdkHandlersProvider<ConsentPolicySdkHandlers> & IPageDidMountHandler => {
		const sdkListeners: Array<ConsentPolicyUpdatesListener> = []
		const consentUpdatesListener: ConsentPolicyUpdatesListener = (policyDetails, policyHeaderObject) => {
			sdkListeners.forEach((listener) => listener(policyDetails, policyHeaderObject))
		}

		return {
			pageDidMount() {
				const unregister = consentPolicyApi.registerToChanges(consentUpdatesListener)
				return () => unregister()
			},
			getSdkHandlers: () => ({
				consentPolicy: {
					setConsentPolicy: (policy: ConsentPolicy) => consentPolicyApi.setConsentPolicy(policy),
					resetConsentPolicy: () => consentPolicyApi.resetConsentPolicy(),
					registerToConsentPolicyUpdates: (listener: ConsentPolicyUpdatesListener) => {
						sdkListeners.push(listener)
					},
				},
			}),
		}
	}
)
