export const name = 'headerContainer' as const
