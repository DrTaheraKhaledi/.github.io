export const name = 'telemetryWixCodeSdk' as const
export const namespace = 'telemetry' as const
