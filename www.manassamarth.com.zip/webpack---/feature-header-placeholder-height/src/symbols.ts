export const name = 'headerPlaceholderHeight' as const
