export const name = 'ooiTpaSharedConfig' as const
export const OoiTpaSharedConfigSymbol = Symbol('ooiTpaSharedConfig')
