export const name = 'datePicker' as const
export const ComponentType = 'DatePicker'
