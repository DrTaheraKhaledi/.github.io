export const name = 'qaApi' as const
