export const ModuleMetadataSymbol = Symbol.for('module metadata')
