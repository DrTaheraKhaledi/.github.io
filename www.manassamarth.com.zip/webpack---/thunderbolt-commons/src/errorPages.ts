export const errorPagesIds: { [key: string]: string } = {
	__403__dp: '__403__dp',
	__404__dp: '__404__dp',
	__500__dp: '__500__dp',
	__uknown_error__dp: '__uknown_error__dp',
}
