export const name = 'addressInput' as const

export const ComponentType = 'AddressInput'
