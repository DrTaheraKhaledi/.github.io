export const Translate = Symbol('Translate')
