export const ReporterSymbol = Symbol('ReporterSite')
