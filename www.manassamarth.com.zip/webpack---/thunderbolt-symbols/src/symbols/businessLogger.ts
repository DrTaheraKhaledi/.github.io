export const BusinessLoggerSymbol = Symbol('BusinessLogger')
